import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { getUser, isAdmin } from "@/lib/auth";
import { sendSms } from "@/lib/sms";
import { PH_MOBILE, PLACES, SERVICES, TIMES } from "@/lib/constants";

const today = () => new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Manila" });

const schema = z.object({
  patient: z.string().trim().min(2).max(80),
  phone: z.string().trim().regex(PH_MOBILE),
  service: z.enum(SERVICES),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine((d) => d >= today(), "Date is in the past"),
  time: z.enum(TIMES),
  place: z.enum(PLACES),
  notes: z.string().trim().max(500).optional().default(""),
});

// Create an appointment, save it, and text it to the hotline.
export async function POST(req: Request) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Log in to book an appointment." }, { status: 401 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Check the form: a field is missing or not valid.", details: parsed.error.flatten().fieldErrors },
      { status: 400 }
    );
  }
  const a = parsed.data;

  const created = await db.appointment.create({ data: { ...a, userId: user.id } });
  const ref = created.id.slice(-6).toUpperCase();

  const text =
    `KALINGAYA APPOINTMENT REQUEST\n` +
    `Patient: ${a.patient}\nPhone: ${a.phone}\nService: ${a.service}\n` +
    `Date: ${a.date}, ${a.time}\nVisit at: ${a.place}` +
    (a.notes ? `\nNotes: ${a.notes}` : "") +
    `\nRef: ${ref}`;

  const hotline = process.env.HOTLINE_NUMBER ?? "09562634472";
  const sms = await sendSms(hotline, text);

  if (process.env.SEND_PATIENT_CONFIRMATION === "true") {
    await sendSms(
      a.phone,
      `Kalingaya: we received your request for ${a.service} on ${a.date} (${a.time}). We will call to confirm. Ref ${ref}`
    );
  }

  const appointment = await db.appointment.update({
    where: { id: created.id },
    data: { smsSent: sms.ok, smsError: sms.ok ? null : sms.error },
  });

  // The booking is saved even if the SMS fails; the client can fall back to the sms: link.
  return NextResponse.json({ appointment, smsSent: sms.ok, smsText: text }, { status: 201 });
}

// List my appointments. Admins can add ?all=1 to list everyone's.
export async function GET(req: Request) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Log in first." }, { status: 401 });

  const all = new URL(req.url).searchParams.get("all") === "1" && isAdmin(user.email);
  const appointments = await db.appointment.findMany({
    where: all ? {} : { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 200,
  });
  return NextResponse.json({ appointments });
}
