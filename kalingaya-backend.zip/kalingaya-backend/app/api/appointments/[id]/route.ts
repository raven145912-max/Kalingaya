import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { getUser, isAdmin } from "@/lib/auth";

const schema = z.object({ status: z.enum(["CONFIRMED", "CANCELLED"]) });

// Admins can confirm or cancel any appointment. Patients can only cancel their own.
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Log in first." }, { status: 401 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Status must be CONFIRMED or CANCELLED." }, { status: 400 });

  const { id } = await params;
  const appt = await db.appointment.findUnique({ where: { id } });
  if (!appt) return NextResponse.json({ error: "Appointment not found." }, { status: 404 });

  const admin = isAdmin(user.email);
  const own = appt.userId === user.id;
  if (!admin && !(own && parsed.data.status === "CANCELLED")) {
    return NextResponse.json({ error: "You are not allowed to do that." }, { status: 403 });
  }
  const appointment = await db.appointment.update({ where: { id }, data: { status: parsed.data.status } });
  return NextResponse.json({ appointment });
}
