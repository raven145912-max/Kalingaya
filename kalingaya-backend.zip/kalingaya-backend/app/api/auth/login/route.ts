import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";

const schema = z.object({ email: z.string().trim().email(), password: z.string().min(1).max(100) });

export async function POST(req: Request) {
  const parsed = schema.safeParse(await req.json().catch(() => null));
  const fail = () => NextResponse.json({ error: "Email or password is not correct." }, { status: 401 });
  if (!parsed.success) return fail();

  const user = await db.user.findUnique({ where: { email: parsed.data.email.toLowerCase() } });
  if (!user || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) return fail();

  await createSession(user.id);
  return NextResponse.json({ user: { id: user.id, email: user.email, name: user.name, phone: user.phone } });
}
