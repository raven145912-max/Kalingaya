import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";
import { PH_MOBILE } from "@/lib/constants";

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  phone: z.string().trim().regex(PH_MOBILE),
  email: z.string().trim().email().max(120),
  password: z.string().min(8).max(100),
});

export async function POST(req: Request) {
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Check your details: use a valid email, a PH mobile number and a password of 8+ characters." },
      { status: 400 }
    );
  }
  const { name, phone, password } = parsed.data;
  const email = parsed.data.email.toLowerCase();

  if (await db.user.findUnique({ where: { email } })) {
    return NextResponse.json({ error: "That email already has an account. Log in instead." }, { status: 409 });
  }
  const user = await db.user.create({
    data: { name, phone, email, passwordHash: await bcrypt.hash(password, 12) },
    select: { id: true, email: true, name: true, phone: true },
  });
  await createSession(user.id);
  return NextResponse.json({ user }, { status: 201 });
}
