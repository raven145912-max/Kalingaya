import { NextResponse } from "next/server";
import { getUser, isAdmin } from "@/lib/auth";

export async function GET() {
  const user = await getUser();
  if (!user) return NextResponse.json({ user: null }, { status: 401 });
  return NextResponse.json({ user: { ...user, isAdmin: isAdmin(user.email) } });
}
