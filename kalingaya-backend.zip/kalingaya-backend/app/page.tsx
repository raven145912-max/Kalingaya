// Placeholder so the project builds. Replace with the Kalingaya front end.
export default function Home() {
  return (
    <main style={{ fontFamily: "system-ui", padding: 32 }}>
      <h1>Kalingaya API is running</h1>
      <p>Endpoints: /api/auth/*, /api/appointments</p>
    </main>
  );
}
