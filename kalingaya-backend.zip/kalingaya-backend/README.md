# Kalingaya backend (Next.js)

API routes for accounts, appointments, and automatic SMS to the hotline (09562634472).

| Method | Route | What it does |
|---|---|---|
| POST | /api/auth/register | Create account and log in (sets a secure cookie) |
| POST | /api/auth/login | Log in |
| POST | /api/auth/logout | Log out |
| GET | /api/auth/me | Current user (401 if logged out) |
| POST | /api/appointments | Save an appointment and SMS it to the hotline |
| GET | /api/appointments | My appointments (`?all=1` for admins) |
| PATCH | /api/appointments/:id | `{ "status": "CONFIRMED" or "CANCELLED" }` |

## 1. Set up services
1. **Database:** create a free Postgres database (Neon, Supabase, or Vercel Postgres) and copy its connection string.
2. **SMS:** create a Semaphore account at semaphore.co, add credits, and copy your API key. Register a sender name if you want one.
3. Copy `.env.example` to `.env` and fill it in. Make `AUTH_SECRET` with `openssl rand -base64 32`.

## 2. Run locally
```bash
npm install
npx prisma db push      # creates the tables
npm run dev
```

## 3. Deploy to Vercel
1. Push this folder to a GitHub repository.
2. In Vercel choose **Add New > Project** and import the repo.
3. Add every variable from `.env.example` under **Environment Variables**.
4. Deploy. Then run `npx prisma db push` once against the production `DATABASE_URL` (from your computer with that variable set).

## 4. Connect the front end
Use `fetch` on the same origin so the login cookie is sent automatically:

```js
// register
await fetch("/api/auth/register", { method: "POST", headers: {"Content-Type":"application/json"},
  body: JSON.stringify({ name, phone, email, password }) });

// book (the server texts 09562634472 for you)
const r = await fetch("/api/appointments", { method: "POST", headers: {"Content-Type":"application/json"},
  body: JSON.stringify({ patient, phone, service, date, time, place, notes }) });
const { smsSent, smsText } = await r.json();
// if smsSent is false, fall back to: location.href = "sms:09562634472?&body=" + encodeURIComponent(smsText)
```

Valid values are in `lib/constants.ts`. Phones use `09XXXXXXXXX` or `+639XXXXXXXXX`.

## Notes
- The hotline number must be a mobile number that can receive SMS.
- Admins are the emails in `ADMIN_EMAILS`. They can list all appointments and confirm or cancel.
- Before launch, add rate limiting to login, register and booking (for example Upstash Ratelimit) to prevent abuse and SMS credit drain.
- Health details are sensitive personal data. Check the requirements of the Philippine Data Privacy Act for your facility.
