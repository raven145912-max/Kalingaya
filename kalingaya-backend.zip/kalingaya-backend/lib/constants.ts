export const SERVICES = [
  "Residential Care",
  "Daily Personal Assistance",
  "Health Monitoring",
  "Nutritious Meals",
  "Recreation and Wellness",
  "Respite Care",
  "Not sure yet",
] as const;

export const TIMES = [
  "Morning (7-11am)",
  "Midday (11am-2pm)",
  "Afternoon (2-5pm)",
  "Evening (5-7pm)",
] as const;

export const PLACES = ["Kalingaya facility, Candelaria", "Patient's home"] as const;

// 09XXXXXXXXX or +639XXXXXXXXX
export const PH_MOBILE = /^(09|\+639)\d{9}$/;
