// Sends SMS through Semaphore (https://semaphore.co), a Philippine SMS gateway.
export async function sendSms(number: string, message: string) {
  const apikey = process.env.SEMAPHORE_API_KEY;
  if (!apikey) return { ok: false as const, error: "SEMAPHORE_API_KEY is not set" };

  const body = new URLSearchParams({ apikey, number, message });
  if (process.env.SEMAPHORE_SENDER_NAME) body.set("sendername", process.env.SEMAPHORE_SENDER_NAME);

  try {
    const res = await fetch("https://api.semaphore.co/api/v4/messages", { method: "POST", body });
    if (!res.ok) return { ok: false as const, error: `Semaphore returned HTTP ${res.status}` };
    return { ok: true as const };
  } catch (e) {
    return { ok: false as const, error: e instanceof Error ? e.message : "SMS request failed" };
  }
}
